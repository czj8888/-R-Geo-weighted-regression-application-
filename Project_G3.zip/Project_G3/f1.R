library(tidyverse)
library(rgdal)
library(ggmap)
library(tmap)
library(RColorBrewer)
library(classInt)
library(lubridate)
library(ggplot2)
library(leaflet)
library(htmltools)
library(spgwr)
library(pryr)
library(rmapshaper)
library(GWmodel)
leafletmappp<-function(column,band_adapt,gweight,bandwidth_method,distance,y_variable,x_variable,color_classes,palette_function,selectedd){
  
  #cn<-readOGR("C:/Users/ASUS/Desktop/CHN_adm_shp",layer = "CHN_adm2")
  #  cn2<-ms_simplify(cn)
  #new<-read_csv("C:/Users/ASUS/Desktop/table.csv")
  #filter the shapefile
  
  selected_cities_in_rdata<-paste(new$NAME_1,new$NAME_2)
  all_cities_in_shp<-paste(cn$NAME_1,cn$NAME_2)
  
  selected_shp<-match(selected_cities_in_rdata,all_cities_in_shp)
  selected_rawdata<-match(selected_cities_in_rdata,paste(new$NAME_1,new$NAME_2))
  cn<-cn2[selected_shp,]
  
  #input variable
  #3 inputs for now: 
  #1.the variable you want to display
  #2.gwr bandwidth_adapt method
  #3.gwr kernal function
  #4.bandwidth optimization method (cv or AIC)
  #3.all input variables for regression model (like c("agriculture","industry","service"))
  
  
  #column<-"No_Higher_Institution"
  #band_adapt<-"adaptive"
  #gweight<-"bisquare"
  #bandwidth_method<-"AIC"
  #distance<-"Euclidean"
  #y_variable<-"GDP_billion_b"
  #x_variable<-c("City_Construction_Rate","No_Higher_Institution","Average_wage_RMB")
  #color_classes<-6
  #palette_function<-"colorBins"
  
  
  column<-column
  band_adapt<-band_adapt
  gweight<-gweight
  bandwidth_method<-bandwidth_method
  distance<-distance
  y_variable<-y_variable
  x_variable<-x_variable
  color_classes<-color_classes
  palette_function<-palette_function
  
  
  
  #pickout the selected x variables from raw data (y is hardcoded)
  
  #merge with shapefile  
  cn<-merge(cn,new,by=c("NAME_1","NAME_2"))
  
  #GWR
  #col index of selected X
  reg_index<-match(x_variable,names(cn@data))
  reg_index
  #col index of selected y
  reg_index2<-which(names(cn@data)==c(y_variable))
  reg_index2
  #Run Regression
  #adabtive bandwidth
  #aa<-bw.gwr(GDP_billion_b~City_Construction_Rate+No_Higher_Institution+Teacher_Student,data=cn,kernel="bisquare")
  #bb<-gwr.basic(GDP_billion_b~City_Construction_Rate+No_Higher_Institution+Teacher_Student,data=cn,bw=aa,kernel = "bisquare",adaptive = FALSE)
  #bb
  
  
  if(band_adapt=="adaptive"){adaptive_value<-TRUE
  if(band_adapt=="global"){adaptive_value<-FALSE}}
  
  if(distance=="Euclidean"){distance_value<-2}
  
  bandwidth<-bw.gwr(as.formula
                    (paste(colnames(cn@data)[reg_index2], "~",
                           paste(colnames(cn@data)[reg_index], collapse = "+"),
                           sep = "")),
                    data=cn,
                    adapt=adaptive_value,
                    kernel = gweight,
                    approach = bandwidth_method,
                    p=distance_value
  )
  res.adpt1<-gwr.basic(as.formula
                       (paste(colnames(cn@data)[reg_index2], "~",
                              paste(colnames(cn@data)[reg_index], collapse = "+"),
                              sep = "")),
                       data=cn,
                       bw=bandwidth,
                       kernel = gweight,
                       p=distance_value,adaptive = adaptive_value
  )
  #global bandwidth
  
  res.adpt1
  res.adpt2<-gwr.t.adjust(res.adpt1)
  #regression model
  
  
  #d is the dataframe for regression result 
  d<-res.adpt1$SDF
  d@data$province<-new[selected_rawdata,]$NAME_1
  d@data$city<-new[selected_rawdata,]$NAME_2
  
  d2<-res.adpt2$SDF
  d2@data$province<-new[selected_rawdata,]$NAME_1
  d2@data$city<-new[selected_rawdata,]$NAME_2
  #coefficient & P value
  if (column=="Intercept"){
    coefficient<-d@data$Intercept
    index<-which(names(d@data)==column)
    index_tv<-which(names(d@data)=="Intercept_TV")
    index_pv<-which(names(d2@data)=="Intercept_p")}
  
  if(column=="residual"){
    coefficient<-d@data$residual
    index<-which(names(d@data)=="residual")}
  
  
  if((column!="Intercept")&(column!="residual")){
    coefficient<-d@data$column
    
    column_tv<-paste(column,"_TV",sep="")
    column_pv<-paste(column,"_p",sep="")
    index<-which(names(d@data)==column)
    
    index_tv<-which(names(d@data)==column_tv)
    index_pv<-which(names(d2@data)==column_pv)}
  
  
  
  #get p value
  row_n<-nrow(d@data)
  columnn<-d@data[index]
  columnnn<-as.numeric(unlist(columnn))
  columnn_t<-d@data[index_tv]
  columnn_p<-d2@data[index_pv]
  columnn_pp<-as.numeric(unlist(columnn_p))
  
  d@data$p<-columnn_pp
  
  #The popup window based on selected variable
  if(column=="residual"){
    popup<-paste0(
      "residual:",br(),coefficient)
    legend_title<-paste("R2:",res.adpt1$GW.diagnostic$gw.R2,br(),"Adj R2:",res.adpt1$GW.diagnostic$gwR2.adj)
    
  }
  if(column!="residual"){
    popup<-paste0(
      paste(d@data$province,d@data$city),"coefficient:",br(),
      d@data[[index]],br(),
      "t: ",d@data[[index_tv]],br(),
      "bandwidth: ",bandwidth,br(),
      "p:",d@data$p)
    legend_title<-paste("coefficient:",column)
    
  }
  
  
  #color pal
  pal<-colorNumeric(palette="Blues",domain=columnn,n=5)
  pal_p<-colorNumeric(palette="Blues",domain=columnn_pp)
  
  levels <- c(-Inf, 0.01, 0.05, 0.1, Inf)
  labels <- c("significant at 99%", "significant at 95%", "significant at 90%", "not significant at 90%")
  column_conflevel <- cut(columnn_pp, levels, labels)
  pal_conf <- colorFactor(
    palette = c('#f7fbff','#9ecae1', '#2171b5', '#08306b'),
    domain = column_conflevel)
  
  
  #Leaflet--coefficients
  
  leaflet(d)%>%
    addTiles()%>%
    addPolygons( color = "#444444",weight = 1, smoothFactor = 0.5,
                 opacity = 1.0, fillOpacity = 0.5,
                 #color panel
                 fillColor =~pal(columnnn),
                 highlightOptions = highlightOptions(color = "red", weight = 2),
                 popup=popup,
                 popupOptions = popupOptions(maxWidth ="100%", closeOnClick = TRUE))%>%
    addLegend("bottomright", pal = pal, values = ~d@data[[index]],
              title = legend_title,
              opacity = 1)
  
  #Leaflet--p_value   
  if(column=="residual"){
    #为空，residual 不显示p value
    
  }
  if(column!="residual"){
    leaflet(d)%>%
      addTiles%>%
      addPolygons( color = "#444444",weight = 1, smoothFactor = 0.5,
                   opacity = 1.0, fillOpacity = 0.5,
                   #color panel
                   fillColor =~pal_conf(column_conflevel),
                   highlightOptions = highlightOptions(color = "red", weight = 2),
                   popup=popup,
                   popupOptions = popupOptions(maxWidth ="100%", closeOnClick = TRUE))%>%
      addLegend("bottomright", pal = pal_conf, 
                values =~column_conflevel,
                title = paste("p-value:",column),
                opacity = 1)
  }
}

#run the model with 8 Inputs：
#1.displaying variable， 2.bandwidth adapt, y variable, x, color segments, coloring method
#leafletmappp("Intercept","adaptive","bisquare","cv","Euclidean","GDP_billion_b",c("City_Construction_Rate","No_Higher_Institution","Average_wage_RMB"),6,"colorBins")
