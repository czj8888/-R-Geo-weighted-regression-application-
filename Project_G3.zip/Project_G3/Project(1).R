#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(tidyverse)
library(rgdal)
library(ggmap)
library(tmap)
library(RColorBrewer)
library(classInt)
library(lubridate)
library(ggplot2)
library(leaflet)
library(htmltools)
library(spgwr)
library(GGally)
library(parcoords)
library(shinyWidgets)
library(pryr)
library(rmapshaper)
library(shinythemes)
source("C:/Project_G3/gwr_c.R")
source("C:/Project_G3/gwr_p.R")
source("C:/Project_G3/lnr.R")
source("C:/Project_G3/lnr_tab.R")


cn<-readOGR("C:/Project_G3/CHN_adm_shp",layer = "CHN_adm2")
#cn2<-ms_simplify(cn)
cn<-cn2[c(1:3,5:17,20:28,163:186,244:261,334:344),]
new <-read_csv("C:/Project_G3/table.csv")


ui <- tagList(
  shinythemes::themeSelector(),

  navbarPage("Geographically Weighted Regression Analysis",
##tab0##            
           theme = shinytheme("darkly"),
             tabPanel("Update File",
                      sidebarLayout(
                        sidebarPanel(
                          fileInput("file1", "Please choose CSV File",
                                    multiple = TRUE,
                                    accept = c("text/csv",
                                               "text/comma-separated-values,text/plain",
                                               ".csv")),
                          
                          # Horizontal line ----
                          tags$hr(),
                          
                          # Input: Checkbox if file has header ----
                          checkboxInput("header", "Header", TRUE),
                          
                          # Input: Select separator ----
                          radioButtons("sep", "Separator",
                                       choices = c(Comma = ",",
                                                   Semicolon = ";",
                                                   Tab = "\t"),
                                       selected = ","),
                          
                          # Input: Select quotes ----
                          radioButtons("quote", "Quote",
                                       choices = c(None = "",
                                                   "Double Quote" = '"',
                                                   "Single Quote" = "'"),
                                       selected = '"'),
                          
                          # Horizontal line ----
                          tags$hr(),
                          
                          # Input: Select number of rows to display ----
                          radioButtons("disp", "Display",
                                       choices = c(Head = "head",
                                                   All = "all"),
                                       selected = "head")
                          
                        ),
                        
                        
                        mainPanel(
                          tableOutput("contents")
                        )
                      )
             ),
##tab variables##
             tabPanel("Select Variables",
                      sidebarLayout(
                        sidebarPanel(pickerInput("explore",
                                                 h3("Please select variable(s) to explore:"),
                                                 choices = colnames(new)[-(1:2)],
                                                 options = list(`selected-text-format`= "count",
                                                                `count-selected-text` = "{0}/{1} variable(s) choosed",
                                                                `actions-box` = TRUE,
                                                                `deselect-all-text` = "None...",
                                                                `select-all-text` = "I want all !",
                                                                `none-selected-text` = "Come on!   Let's select ! "),
                                                 multiple = TRUE),
                                     br(),
                                     br(),
                                     tags$hr(),
                                     
                                     selectInput("model", 
                                                 h3("Please select model"),
                                                 choices = list("Mutiple Linear Regression", 
                                                                "Geographically Weighted Regression"),
                                                 selected = "Geographical Weighted Regression"),
                                     br(),
                                     br(),
                                     tags$hr(),
                                     
                                     selectInput("target", 
                                                 h3("Please select target"),
                                                 choices = colnames(new)[-(1:2)]),
                                     pickerInput("variable",
                                                 h3("Please select variables"),
                                                 choices = list(),
                                                 options = list(`selected-text-format`= "count",
                                                                `count-selected-text` = "{0}/{1} variable(s) choosed",
                                                                `actions-box` = TRUE,
                                                                `deselect-all-text` = "None...",
                                                                `select-all-text` = "All in !  (Maybe not wise)",
                                                                `none-selected-text` = "Come on!   Let's select ! "),
                                                 multiple = TRUE)
                        ),
                        
                        mainPanel(
##BUG                                  
                                  "Overview of entire variables",
                                  plotOutput("matrix",height = 320),
                                  "Parallel Croodiantes",
                                  parcoordsOutput("pr",height = 320)
                                  )
                        )
                      ),
                      
             
##tab2##      
             tabPanel("Modeling", 
                      sidebarLayout(
                        sidebarPanel(h3("Target: You have selected:"),
                                     verbatimTextOutput("selected_target"),
                                     h3("Variables: You have selected:"),
                                     verbatimTextOutput("selected_variable"),
                                     h3("Model: You have selected:"),
                                     verbatimTextOutput("selected_model"),
                                     
                                     br(),
                                     br(),
                                     tags$hr(),
                                     pickerInput("display", 
                                                 h3("Please choose a variable to display"),
                                                 choices = list(),
                                                 selected = x[1]),
                                    
                                    
                                     h3("You have selected:"),
                                     textOutput("selected_display")),
                        
                        
                        mainPanel(
                          conditionalPanel(
                            condition = "input.model == 'Mutiple Linear Regression'",
                            radioGroupButtons(inputId = "layout2", 
                                              choices = c("Vertical Layout", "Horizontal Layout"), 
                                              status = "primary",
                                              selected = "Vertical Layout"),
                            conditionalPanel(
                              condition = "input.layout2 == 'Vertical Layout'",
                            
                            leafletOutput("lnr_coefficient",height = 350),
                            br(),
                            tags$hr(),
                            "Linear regression model outcome",
                            br(),
                            tableOutput("lnr_outcome")
                            ),
                            
                            conditionalPanel(
                              condition = "input.layout2 == 'Horizontal Layout'",
                              fluidRow(column(6,leafletOutput("lnr_coefficient2",height = 600)),
                                       column(6,"Linear regression model outcome",
                                              tableOutput("lnr_outcome2"))
                              )
                            )
                          ),
                          
                     conditionalPanel(
                            condition = "input.model == 'Geographically Weighted Regression'",
                            radioGroupButtons(inputId = "layout", 
                                              choices = c("Vertical Layout", "Horizontal Layout"), 
                                              status = "primary",
                                                   selected = "Vertical Layout"),
                            conditionalPanel(
                              condition = "input.layout == 'Vertical Layout'",
                            
                           
                            leafletOutput("map_coeffcient",height = 350),
                            
                            dropdownButton(
                              tags$h3("List of Input"),
                              size = "xs",
                              up = TRUE,
                              selectInput(inputId = 'xcol', label = 'X Variable', choices = names(iris)),
                              selectInput(inputId = 'ycol', label = 'Y Variable', choices = names(iris), selected = names(iris)[[2]]),
                              sliderInput(inputId = 'clusters', label = 'Cluster count', value = 3, min = 1, max = 9),
                              circle = TRUE, status = "danger", icon = icon("gear"), width = "300px",
                              tooltip = tooltipOptions(title = "Click to see inputs !")
                            ),
                            br(),
                            
                            radioGroupButtons(inputId = "control", 
                                              choices = c("Model Outcome", "p-value"), 
                                              status = "primary",
                                              selected = "p-value",
                                              size = 'sm'),
                            
                            conditionalPanel(
                              condition = "input.control == 'p-value'",
                              leafletOutput("map_p_value",height = 350),
                              dropdownButton(
                                tags$h3("List of Input"),
                                size = "xs",
                                up = TRUE,
                                selectInput(inputId = 'xcol', label = 'X Variable', choices = names(iris)),
                                selectInput(inputId = 'ycol', label = 'Y Variable', choices = names(iris), selected = names(iris)[[2]]),
                                sliderInput(inputId = 'clusters', label = 'Cluster count', value = 3, min = 1, max = 9),
                                circle = TRUE, status = "danger", icon = icon("gear"), width = "300px",
                                tooltip = tooltipOptions(title = "Click to see inputs !")
                              )
                            )
                          ),
                          conditionalPanel(
                            condition = "input.layout=='Horizontal Layout'",
                            fluidRow(column(6,
                                            leafletOutput("map_coeffcient2",height = 600),
                                            dropdownButton(
                                              tags$h3("List of Input"),
                                              size = "sm",
                                              up = TRUE,
                                              selectInput(inputId = 'xcol', label = 'X Variable', choices = names(iris)),
                                              selectInput(inputId = 'ycol', label = 'Y Variable', choices = names(iris), selected = names(iris)[[2]]),
                                              sliderInput(inputId = 'clusters', label = 'Cluster count', value = 3, min = 1, max = 9),
                                              circle = TRUE, status = "danger", icon = icon("gear"), width = "300px",
                                              tooltip = tooltipOptions(title = "Click to see inputs !")
                                            )),
                                     column(6,leafletOutput("map_p_value2",height = 600),
                                            dropdownButton(
                                              tags$h3("List of Input"),
                                              size = "sm",
                                              up = TRUE,
                                              selectInput(inputId = 'xcol', label = 'X Variable', choices = names(iris)),
                                              selectInput(inputId = 'ycol', label = 'Y Variable', choices = names(iris), selected = names(iris)[[2]]),
                                              sliderInput(inputId = 'clusters', label = 'Cluster count', value = 3, min = 1, max = 9),
                                              circle = TRUE, status = "danger", icon = icon("gear"), width = "300px",
                                              tooltip = tooltipOptions(title = "Click to see inputs !")
                                            )))
                            )
                          )
                        )
                      )
             ),
             
       
##tab 3:spare menu##
             navbarMenu("More",
                        tabPanel("Summary",
                                 p("let us summmaized the economical growth of industries.")
                                 ),
                        "----",
                        "Section header",
                        tabPanel("Data Overview",
                                 pickerInput("rawdatadisplay", 
                                             h3("Raw data overview"),
                                             choices = colnames(new)[-1],
                                             multiple = TRUE),
                                 tableOutput("rawdata"))
             )
  )
)
server <- function(input, output,session) {


  

##panel 0,right side
  output$contents <- renderTable({

    
    # input$file1 will be NULL initially. After the user selects
    # and uploads a file, head of that data file by default,
    # or all rows if selected, will be shown.
    
      req(input$file1)
    
      new2 <- read.csv(input$file1$datapath,
                    header = input$header,
                    sep = input$sep,
                    quote = input$quote)
      
      #assign to new data table
      new1 <- read_csv(input$file1$datapath,
                      col_names = TRUE,
                      quote = input$quote)
      new <<-new1

      a <- colnames(new)[-(1:2)]
      b <- input$target
      

      updatePickerInput(session, "explore",
                        choices = a[!a%in%b],selected = colnames(new)[-(1:2)][2])
      
      updatePickerInput(session, "target",
                        choices = a)
      
      updatePickerInput(session, "variable",
                        choices = a[!a%in%b])
  
    
    if(input$disp == "head") {
      return(head(new2))
    }
    else {
      return(new2)
    }
    
  })
  
  
  
##panel 1, left side  
  # sub-selected displaied option#
  observe({
    x <- input$variable
    updatePickerInput(session, "display",choices = c(x,"Intercept","residual"))
  })
  

  #explore  
  observe({
    a <- colnames(new)[-(1:2)]
    b <- input$target

    updatePickerInput(session, "explore",
                      choices = a[!a%in%b],
                      selected = colnames(new)[-(1:2)][2])
  })
  
  #variable  
  observe({
    a <- colnames(new)[-(1:2)]
    b <- input$target
    
    updatePickerInput(session, "variable",
                      choices = a[!a%in%b])
  })
  

##panel 1, right side  
 # matrix #
  output$matrix <- renderPlot({
    ggpairs(new, columns = c(input$explore))
  })
  
 # paralle coordinate#
  output$pr <- renderParcoords({
    parcoords(new[c(input$explore)],
              rownames = F,
              reorderable = TRUE,
              brushMode = "1d-multi",
              queue = T,
              color = list(colorBy = "NAME_2")
    )
  })


##panel 2, right side   
  
 #linear regression coefficient map 1
  output$lnr_coefficient <- renderLeaflet({
    lineareg(cn,cn2,new,input$target,c(input$variable))
  })
  
  #linear regression outcome 1
  output$lnr_outcome <- renderTable({
    lineartab(cn,cn2,new,input$target,c(input$variable))
  },rownames = TRUE,hover = TRUE, bordered = TRUE)
  
  #linear regression coefficient map 2
  output$lnr_coefficient2 <- renderLeaflet({
    lineareg(cn,cn2,new,input$target,c(input$variable))
  })
  
  #linear regression outcome 2
  output$lnr_outcome2 <- renderTable({
    lineartab(cn,cn2,new,input$target,c(input$variable))
  },rownames = TRUE,hover = TRUE, bordered = TRUE)
  
 #coefficient map 1
  output$map_coeffcient <- renderLeaflet({
    leafletmap_coeffcient(cn,cn2,new,input$display,
                "adaptive","bisquare","cv","Euclidean",
                input$target,
                c(input$variable),6,"colorBins")
  })

  
  
 #p-value map  1
  output$map_p_value <- renderLeaflet({
    leafletmap_pvalue(cn,cn2,new,input$display,
                "adaptive","bisquare","cv","Euclidean",
                input$target,
                c(input$variable),6,"colorBins")
  })

  #coefficient map2
  output$map_coeffcient2 <- renderLeaflet({
    leafletmap_coeffcient(cn,cn2,new,input$display,
                          "adaptive","bisquare","cv","Euclidean",
                          input$target,
                          c(input$variable),6,"colorBins")
  })
  
  
  #p-value map  2
  output$map_p_value2 <- renderLeaflet({
    leafletmap_pvalue(cn,cn2,new,input$display,
                "adaptive","bisquare","cv","Euclidean",
                input$target,
                c(input$variable),6,"colorBins")
  })
  
    
 #lr##

  
  
  output$selected_target <- renderText({ 
    (input$target)
  })
  output$selected_variable <- renderText({ 
    (input$variable)
  })
  output$selected_model <- renderText({ 
    (input$model)
  })
  output$selected_display <- renderText({ 
    (input$display)
  })
  
  
##panel 3
  #rawdata show
    output$rawdata <- renderTable({
      new[, c(colnames(new)[1], input$rawdatadisplay), drop = FALSE]
    }, rownames = TRUE)

  
}
shinyApp (ui=ui, server=server)
