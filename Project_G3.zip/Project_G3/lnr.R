library(tidyverse)
library(rgdal)
library(ggmap)
library(tmap)
library(RColorBrewer)
library(classInt)
library(lubridate)
library(ggplot2)
library(leaflet)
library(htmltools)
library(spgwr)
library(pryr)
library(rmapshaper)
library(GWmodel)
library(olsrr)
lineareg<-function(cn,cn2,new,y_variable,x_variable){
  
  cn<-readOGR("C:/Project_G3/CHN_adm_shp",layer = "CHN_adm2")
  #  cn2<-ms_simplify(cn)
  #new<-read_csv("C:/Project_G3/table.csv")
  #filter the shapefile
  
  selected_cities_in_rdata<-paste(new$NAME_1,new$NAME_2)
  all_cities_in_shp<-paste(cn$NAME_1,cn$NAME_2)
  
  selected_shp<-match(selected_cities_in_rdata,all_cities_in_shp)
  selected_rawdata<-match(selected_cities_in_rdata,paste(new$NAME_1,new$NAME_2))
  cn<-cn2[selected_shp,]
  
  #input variable
  #3 inputs for now: 
  #1.the variable you want to display
  #2.gwr bandwidth_adapt method
  #3.gwr kernal function
  #4.bandwidth optimization method (cv or AIC)
  #3.all input variables for regression model (like c("agriculture","industry","service"))
  
  
  column<-"residual"
  band_adapt<-"adaptive"
  gweight<-"bisquare"
  bandwidth_method<-"AIC"
  distance<-"Euclidean"
  y_variable<-y_variable
  x_variable<-x_variable
  color_classes<-6
  palette_function<-"colorBins"
  
  
  #column<-column
  #band_adapt<-band_adapt
  #gweight<-gweight
  #bandwidth_method<-bandwidth_method
  #distance<-distance
  #y_variable<-y_variable
  #x_variable<-x_variable
  #color_classes<-color_classes
  #palette_function<-palette_function
  
  
  
  #pickout the selected x variables from raw data (y is hardcoded)
  
  #merge with shapefile  
  cn<-merge(cn,new,by=c("NAME_1","NAME_2"))
  
  #GWR
  #col index of selected X
  reg_index<-match(x_variable,names(cn@data))
  reg_index
  #col index of selected y
  reg_index2<-which(names(cn@data)==c(y_variable))
  reg_index2
  #Run Regression
  #adabtive bandwidth
  #aa<-bw.gwr(GDP_billion_b~City_Construction_Rate+No_Higher_Institution+Teacher_Student,data=cn,kernel="bisquare")
  #bb<-gwr.basic(GDP_billion_b~City_Construction_Rate+No_Higher_Institution+Teacher_Student,data=cn,bw=aa,kernel = "bisquare",adaptive = FALSE)
  #bb
  
  
  if(band_adapt=="adaptive"){adaptive_value<-TRUE
  if(band_adapt=="global"){adaptive_value<-FALSE}}
  
  if(distance=="Euclidean"){distance_value<-2}
  
  bandwidth<-bw.gwr(as.formula
                    (paste(colnames(cn@data)[reg_index2], "~",
                           paste(colnames(cn@data)[reg_index], collapse = "+"),
                           sep = "")),
                    data=cn,
                    adapt=TRUE,
                    kernel = "bisquare",
                    approach = "AIC",
                    p=2
  )
  res.adpt1<-gwr.basic(as.formula
                       (paste(colnames(cn@data)[reg_index2], "~",
                              paste(colnames(cn@data)[reg_index], collapse = "+"),
                              sep = "")),
                       data=cn,
                       bw=bandwidth,
                       kernel = "bisquare",
                       p=2,
                       adaptive = TRUE
  )
  #global bandwidth
  
  res.adpt1
  res.adpt2<-gwr.t.adjust(res.adpt1)
  #regression model
  linear<-res.adpt1$lm
  global_model<-as.data.frame(coefficients(summary(linear)))
  vif<-as.vector(c(0,ols_vif_tol(linear)$VIF))
  
  global_model$VIF<-vif
  global_r.squared<-summary(linear)$r.squared
  global_r.squared.adj<-summary(linear)$adj.r.squared
  

  
  #color pal
  pal<-colorNumeric(palette="Blues",domain=linear$residuals,n=5)
  popup<-paste(cn$NAME_1,cn$NAME_2,br(),"Residual: ",aa)
  #pal_p<-colorNumeric(palette="Blues",domain=columnn_pp)
  
  #levels <- c(-Inf, 0.001, 0.05, 0.1, Inf)
  #labels <- c("significant at 99%", "significant at 95%", "significant at 90%", "not significant at 90%")
  #column_conflevel <- cut(columnn_pp, levels, labels)
  #pal_conf <- colorFactor(
  #palette = c('#f7fbff','#9ecae1', '#2171b5', '#08306b'),
  #domain = column_conflevel)
  
  aa<-linear$residuals
  #Leaflet--coefficients
  
  #linear regression--R2
  global_model_result<-c("R.Squared:",global_r.squared,"R2 Adjusted",global_r.squared.adj)
  #linear regression--p value & VIF
  global_model[order(-global_model$`Pr(>|t|)`),]
  
  leaflet(d)%>%
    addTiles()%>%
    addPolygons( color = "#444444",weight = 1, smoothFactor = 0.5,
                 opacity = 1.0, fillOpacity = 0.5,
                 #color panel
                 fillColor =~pal(aa),
                 highlightOptions = highlightOptions(color = "red", weight = 2),
                 popup=popup,
                 popupOptions = popupOptions(maxWidth ="100%", closeOnClick = TRUE))%>%
    addLegend("bottomright", pal = pal, values = ~aa,
              title = paste("R2:",global_r.squared,br(),"Adj R2:",global_r.squared.adj ),
              opacity = 1)
  
  #Leaflet--p_value   
  
  
  
  
}
#run the model with 8 Inputs:
#1.displaying variable, 2.bandwidth adapt, y variable, x, color segments, coloring method

